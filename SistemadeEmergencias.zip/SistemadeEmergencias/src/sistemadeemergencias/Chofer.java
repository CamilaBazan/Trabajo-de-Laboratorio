package sistemadeemergencias;

public class Chofer extends Empleado{
    
    public Chofer(String nombre, String apellido, String domicilio, String dni) {
        super(nombre, apellido, domicilio, dni);
        
        this.setDni(dni);
        this.setApellido(apellido);
        this.setDomicilio(domicilio);
        this.setNombre(nombre);

    }
}
