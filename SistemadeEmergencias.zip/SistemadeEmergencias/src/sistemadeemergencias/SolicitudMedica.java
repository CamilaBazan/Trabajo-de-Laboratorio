package sistemadeemergencias;

public class SolicitudMedica {
    
    private Persona paciente;
    private Doctor doctor;
    private Enfermero enfermero;
    private Movil movil;
    private String diagnostico;

    public SolicitudMedica(Persona paciente,Doctor doctor,Enfermero enfermero,Movil movil) {
        this.paciente=paciente;
        this.doctor=doctor;
        this.enfermero=enfermero;
        this.movil=movil;
   
    }

    public Persona getPaciente() {
        return paciente;
    }

    public void setPaciente(Persona paciente) {
        this.paciente = paciente;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }
 
    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Enfermero getEnfermero() {
        return enfermero;
    }

    public void setEnfermero(Enfermero enfermero) {
        this.enfermero = enfermero;
    }

    public Movil getMovil() {
        return movil;
    }

    public void setMovil(Movil movil) {
        this.movil = movil;
    }
    
}
