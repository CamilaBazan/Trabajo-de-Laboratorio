package sistemadeemergencias;

import java.util.ArrayList;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.AfiliadoInexistente;

public class GestionEmergencia implements Administracion{
    
    private final ArrayList registro = new ArrayList();
    private final ArrayList moviles = new ArrayList();
    
    /*private ArrayList afiliados = new ArrayList();
    private ArrayList solicitudEmergencias =  new ArrayList();
    private ArrayList empleados = new ArrayList();*/
   
    
    /*public void PagoAfiliado(Afiliado afiliado){
    LocalDateTime hoy = LocalDateTime.now();
         if(hoy.isAfter(afiliado.getFechapago())){ 
         JOptionPane.showConfirmDialog(null , "");
         
      } else if(hoy.isBefore(afiliado.getFechapago())){ 
        JOptionPane.showConfirmDialog(null , "");
        
      } else { 
        hoy.equals(afiliado.getFechapago()); 
        JOptionPane.showConfirmDialog(null , "");
        }
    }
    
    public Boolean verificarAfiliado(Afiliado afiliado){//ver despues si funciona de otra manera y con otra funciones
              Boolean a = true;
             LocalDateTime hoy = LocalDateTime.now(); //creo que no haria falta en nuestro caso
             //poner en este metodo el localdatetime si se verificara siexiste o no
              if(ChronoUnit.DAYS.between(afiliado.getFechapago(), hoy)>60){ 
                //queria comparar si setfechapago y importe eran nulos , quiere decir que nunca pago el tipo
                    afiliado.setAbonoHabilitado(false);
                    a = false;
                    JOptionPane.showConfirmDialog(null , "Afiliado inexistente"); //no se realiza la solicitud-o eso es lo que quiero
              }
          return a;    
          }
    //tema del pago
    public Float Importe(Float imp)throws AfiliadoInsuficienteImporte{ 
       float base=200;//se pone una base para que pague el afiliado, y por cada familiar se suma 100
       if (imp>=base){
          return imp;
       }else if(imp<base){
          Float resto=base-imp;
           throw new AfiliadoInsuficienteImporte("Importe insuficiente Afiliado:"+this.afiliados.getnombre()+ "le faltan:"+resto);
       }  

    
   // public void altaAfiliado(Afiliado afiliado) {
        
   //     afiliados.add(afiliado);
   // }
    
    //ver despues si quiero poner mas para borrar (remove) de cada familiar y empleado
    
   /* public void altaEmpleados(Empleado empleado){
        
        empleados.add(empleado);
    }*/
    
    
    /*public void altaDoctor(Doctor doctor){
              empleados.add(doctor);
          } 
          
    public void altaEnfermero(Enfermero enfermero){
              empleados.add(enfermero);
          } 
          
    public void altaChofer(Chofer chofer){
              empleados.add(chofer);
          }
          
        /*  public void bajaChofer(Chofer chofer){
              empleados.remove(chofer);
          }
     public void altaAdmin(Administrador admin){
              empleados.add(admin);
          }*/
    
    
    
    @Override
    public void añadir(Object per) {
        
      Persona pe = (Persona)per;
      Persona existe = (Persona)buscar(pe.getDni());
        if (existe != null) {
            throw new AfiliadoExistente("Afiliado existente " + existe);
        }
        registro.add(pe);
    }

    @Override
    public void eliminar(String dni) {
        Object existe = buscar(dni);
        if (existe != null) {
            registro.remove(existe);            
            return;
        }        
        throw new AfiliadoInexistente("Afiliado inexistente: " + dni);
    }

   

    @Override
    public Object buscar(String dni) {
        Persona resultado = null;
         for (Object cuenta : registro) {
            Persona c = (Persona)cuenta;
            if (c.getDni().equals(dni)==true){
                resultado=c;
            }
        }
        return resultado;

    }

    @Override
    public void añadirMovil(Object mov) {
        Movil movil = (Movil)mov;
        Movil existe = (Movil)buscarMovil(movil.getPatente());
        if (existe != null) {
            throw new AfiliadoExistente("Movil Existente " + existe);
        }
        moviles.add(movil);
    }

    @Override
    public void eliminarMovil(String mov) {
        Object existe = buscarMovil(mov);
        if (existe != null) {
            moviles.remove(existe);            
            return;
        }        
        throw new AfiliadoInexistente("Movil Inexistente: " + mov);
    }

    @Override
    public Object buscarMovil(String patente) {
        Movil resultado = null;
        
            for (Object cuenta : moviles) {
                Movil c = (Movil)cuenta;
                if(c.getPatente().equals(null)){
                    
                }else{
                    if (c.getPatente().equals(patente)==true){
                        resultado=c;
                    }
                }
            }
            return resultado;
        
    }
    @Override
    public Doctor buscarDoc(){
        Doctor resultado = null;
        Doctor d = new Doctor("Cardiologo","Juan","Gonzalez","20654789","San Isidro");
        for(Object c : registro){
            if(c.getClass().equals(d.getClass())){
                resultado = (Doctor) c;
                break;
            }
        }
        return resultado;
    }
    @Override
    public Enfermero buscarEnf(){
        Enfermero resultado = null;
        Enfermero d = new Enfermero("Jose","Carrizo","21658359","Padre Esquiu 500");
        for(Object c : registro){
            if(c.getClass().equals(d.getClass())){
                resultado = (Enfermero) c;
                break;
            }
        }
        return resultado;
    }
    @Override
    public Movil buscarMov(){
        Movil resultado = null;
        Movil mov = new Movil("Peugeot","2010",2010,"ABC 123");
        for(Object c : moviles){
            if(c.getClass().equals(mov.getClass())){
                resultado = (Movil) c;
                break;
            }
        }
        return resultado;
    }
}
