package sistemadeemergencias;

import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;


public class Afiliado extends Persona{
    
    private ArrayList <Persona> familiar;
    private PagarAfiliado pago;

    public Afiliado(String nombre,String apellido,String dni,String domicilio) {
        super();
        familiar= new ArrayList();
        pago=new PagarAfiliado(this);
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setDni(dni);;
        this.setDomicilio(domicilio);
    }    
    
    public ArrayList<Persona> getFamiliar() {
        return familiar;
    }

    public void setFamiliar(ArrayList<Persona> familiar) {
        this.familiar = familiar;
    }

    public PagarAfiliado getPago() {
        return pago;
    }

    public void setPago(PagarAfiliado pago) {
        this.pago = pago;
    }
     public Object buscar(String dni) {
        Persona resultado = null;
         for (Object cuenta : familiar) {
            Persona c = (Persona)cuenta;
            if (c.getDni().equals(dni)==true){
                resultado=c;
            }
        }
        return resultado;

    }
     public ArrayList getListaFam(){
         return familiar;
     }
}
