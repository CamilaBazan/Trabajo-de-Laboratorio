package sistemadeemergencias;

import sistemadeemergencias.ventanas.Principal;

public class SistemadeEmergencias {

    public static void main(String[] args) {
        
        Administracion admin = new GestionEmergencia();
        
        Principal principal = new Principal(admin);
        principal.setLocationRelativeTo(null);
        principal.setVisible(true);
    }
}
