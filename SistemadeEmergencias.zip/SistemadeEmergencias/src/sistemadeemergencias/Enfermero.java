package sistemadeemergencias;

public class Enfermero extends Empleado {
    
    public Enfermero(String nombre, String apellido, String domicilio, String dni) {
        
        super(nombre, apellido, domicilio, dni);
        
        this.setApellido(apellido);
        this.setNombre(nombre);
        this.setDni(dni);
        this.setDomicilio(domicilio);

    }
}
