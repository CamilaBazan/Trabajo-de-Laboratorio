package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.AfiliadoInexistente;
import sistemadeemergencias.excepciones.CampoVacio;


public class SolicitudEmergencia extends javax.swing.JFrame {
    private SolicitudMedica solicitud;
    private Administracion admin;
    private Afiliado persona;
    private Doctor doctor;
    private Enfermero enfermero;
    private Movil movil;
    public SolicitudEmergencia(Administracion admin) {
        this.admin=admin;
        initComponents();
        diagnostico.setEditable(false);
        //aceptar.setEnabled(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        dniS = new javax.swing.JLabel();
        dni = new javax.swing.JTextField();
        SolicitudTitular = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        diagnostico = new javax.swing.JTextArea();
        diag = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Ingrese N° Documento:");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        dniS.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dniS.setText("Ingrese N° Documento:");

        SolicitudTitular.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        SolicitudTitular.setText("Solicitar");
        SolicitudTitular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SolicitudTitularActionPerformed(evt);
            }
        });

        cancelar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });

        diagnostico.setColumns(20);
        diagnostico.setRows(5);
        jScrollPane1.setViewportView(diagnostico);

        diag.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        diag.setText("Diagnostico:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(dniS)
                                .addGap(18, 18, 18)
                                .addComponent(dni, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(diag, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(154, 154, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(SolicitudTitular, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cancelar)
                        .addGap(50, 50, 50))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dniS)
                    .addComponent(dni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addComponent(diag)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SolicitudTitular)
                    .addComponent(cancelar))
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SolicitudTitularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SolicitudTitularActionPerformed
        try{
            if(this.dni.getText().equals("")==true){
                throw new CampoVacio();
            }else{
                persona = (Afiliado)this.admin.buscar(this.dni.getText());
                Boolean respuesta = persona.getPago().compararMes();
                if(respuesta==false){
                    JOptionPane.showMessageDialog(rootPane,"Solicitud Rechazada","ATENCION",0);
                }
                else{
                    Doctor doctor = admin.buscarDoc();
                    Enfermero enfermero = admin.buscarEnf();
                    Movil movil= admin.buscarMov();
                    solicitud = new SolicitudMedica(persona,doctor,enfermero,movil);
                    
                    diagnostico.setEditable(true);
                    //aceptar.setEnabled(true);
                    JOptionPane.showMessageDialog(rootPane,"Solicitud Existosa");
                }
            }
        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        }catch(AfiliadoInexistente e){
            JOptionPane.showMessageDialog(rootPane,"Afiliado Inexistente","ATENCION",0);
        }//catch(java.lang.ClassCastException e){
            //JOptionPane.showMessageDialog(rootPane,"Persona no existente","ATENCION",0);
         catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Ingrese Dni","ATENCION",0);
        }catch (java.lang.NullPointerException ex){
            JOptionPane.showMessageDialog(rootPane,"Personal o Movil no Disponible.","ATENCION",0);
        }    
    }//GEN-LAST:event_SolicitudTitularActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SolicitudTitular;
    private javax.swing.JButton cancelar;
    private javax.swing.JLabel diag;
    private javax.swing.JTextArea diagnostico;
    private javax.swing.JTextField dni;
    private javax.swing.JLabel dniS;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
