package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.CampoVacio;


public class EditarAfiliado extends javax.swing.JFrame {
    private Administracion admin;
    private Afiliado persona;
    private Familiar familia;
    
    //private ValidarCampo campo = new ValidarCampo();
    DefaultListModel listaFamiliar = new DefaultListModel();
    
    
    public EditarAfiliado(Administracion admin, Afiliado afiliado) {
        this.admin=admin;
        this.persona=afiliado;
        
        
        initComponents();
        this.nombre.setText(persona.getNombre());
        this.apeAfi.setText(persona.getApellido());
        this.domicilio.setText(persona.getDomicilio());
        this.listaFlia.setModel(listaFamiliar);
        for(Persona f: persona.getFamiliar()){
            listaFamiliar.addElement(f);
        }
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        limpiar = new javax.swing.JButton();
        nom = new javax.swing.JLabel();
        dom = new javax.swing.JLabel();
        nombre = new javax.swing.JTextField();
        domicilio = new javax.swing.JTextField();
        modificarAdmi = new javax.swing.JButton();
        eliminar = new javax.swing.JButton();
        infoFam = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaFlia = new javax.swing.JList<>();
        modificarF = new javax.swing.JButton();
        eliminarF = new javax.swing.JButton();
        ape = new javax.swing.JLabel();
        apeAfi = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        limpiar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        limpiar.setText("Limpiar Campo");
        limpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarActionPerformed(evt);
            }
        });

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        dom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dom.setText("Domicilio:");

        nombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombreKeyTyped(evt);
            }
        });

        modificarAdmi.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        modificarAdmi.setText("Modificar");
        modificarAdmi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarAdmiActionPerformed(evt);
            }
        });

        eliminar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        eliminar.setText("Eliminar");
        eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarActionPerformed(evt);
            }
        });

        infoFam.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        infoFam.setText("Información Familiares:");

        jScrollPane1.setViewportView(listaFlia);

        modificarF.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        modificarF.setText("Modificar familiar");
        modificarF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarFActionPerformed(evt);
            }
        });

        eliminarF.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        eliminarF.setText("Eliminar Familiar");
        eliminarF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarFActionPerformed(evt);
            }
        });

        ape.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        ape.setText("Apellido:");

        apeAfi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apeAfiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ape)
                            .addComponent(nom)
                            .addComponent(dom)
                            .addComponent(infoFam))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(107, 107, 107)
                                .addComponent(modificarF)
                                .addGap(62, 62, 62)
                                .addComponent(eliminarF))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(apeAfi, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(domicilio, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(117, 117, 117)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(eliminar)
                                    .addComponent(modificarAdmi)
                                    .addComponent(limpiar)))))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 676, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nom)
                            .addComponent(nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(modificarAdmi)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ape)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(apeAfi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(eliminar)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(dom)
                        .addComponent(domicilio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(limpiar))
                .addGap(80, 80, 80)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(infoFam)
                    .addComponent(modificarF)
                    .addComponent(eliminarF))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void limpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarActionPerformed

        this.domicilio.setText(null);
        this.apeAfi.setText(null);
        this.nombre.setText(null);

    }//GEN-LAST:event_limpiarActionPerformed

    private void nombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreKeyTyped

    private void modificarAdmiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarAdmiActionPerformed
        try{
            String aux1=this.nombre.getText().trim();
            String aux2=this.apeAfi.getText().trim();
            String aux3=this.domicilio.getText().trim();
            if(aux1.equals("") || aux2.equals("") || aux3.equals("")){
                throw new CampoVacio();
            }
            else{
                persona.setNombre(this.nombre.getText());
                persona.setApellido(this.apeAfi.getText());
                persona.setDomicilio(this.domicilio.getText());
                
                JOptionPane.showMessageDialog(rootPane, "Afiliado Modificado");
            }
        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campo Vacio","ATENCION",0);
        }

    }//GEN-LAST:event_modificarAdmiActionPerformed

    private void eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarActionPerformed
        try{
            String aux1=this.nombre.getText().trim();
            String aux2=this.apeAfi.getText().trim();
            String aux3=this.domicilio.getText().trim();
            if(aux1.equals("") || aux2.equals("") || aux3.equals("")){
                throw new CampoVacio();

            }
            else{
                this.admin.eliminar(persona.getDni());
                JOptionPane.showMessageDialog(rootPane, "Afiliado Eliminado");
                this.domicilio.setText(null);
                this.apeAfi.setText(null);
                this.nombre.setText(null);
            }
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campo Vacio","ATENCION",0);
        }
    }//GEN-LAST:event_eliminarActionPerformed

    private void modificarFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarFActionPerformed
        int p = listaFlia.getSelectedIndex();
        if(p>=0){
            familia=(Familiar)persona.getFamiliar().get(p);
            EditarFamilia f = new EditarFamilia(familia);
            f.setTitle("MODIFICAR FAMILIAR");
            f.setLocationRelativeTo(null);
            f.setVisible(true);
        }
        else{
            JOptionPane.showMessageDialog(rootPane,"seleccione un familiar","ATENCION",0);
        }
    }//GEN-LAST:event_modificarFActionPerformed

    private void eliminarFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarFActionPerformed
        int p=listaFlia.getSelectedIndex();
        if(p>=0){
            familia=(Familiar)persona.getFamiliar().get(p);
            listaFamiliar.remove(p);
            persona.getFamiliar().remove(familia);
            JOptionPane.showMessageDialog(rootPane,"Familiar Eliminado");
        }
        else{
            JOptionPane.showMessageDialog(rootPane,"Seleccione un Familiar","ATENCION",0);
        }
        
        
    }//GEN-LAST:event_eliminarFActionPerformed

    private void apeAfiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apeAfiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apeAfiActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ape;
    private javax.swing.JTextField apeAfi;
    private javax.swing.JLabel dom;
    private javax.swing.JTextField domicilio;
    private javax.swing.JButton eliminar;
    private javax.swing.JButton eliminarF;
    private javax.swing.JLabel infoFam;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton limpiar;
    private javax.swing.JList<String> listaFlia;
    private javax.swing.JButton modificarAdmi;
    private javax.swing.JButton modificarF;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nombre;
    // End of variables declaration//GEN-END:variables
}
