package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.CampoVacio;


public class RegFamiliar extends javax.swing.JFrame {
    private Afiliado afiliado;
    private ArrayList <Persona> familia;
    //private ValidarCampo va = new ValidarCampo();
    
    public RegFamiliar(Afiliado afiliado) {
        this.afiliado=afiliado;
        familia=new ArrayList();
        initComponents();
        /*va.soloLetra(nombreF);
        va.soloNumero(dniF);
        va.soloNumero(edadF);*/
       
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        nom = new javax.swing.JLabel();
        dni = new javax.swing.JLabel();
        dom = new javax.swing.JLabel();
        nomFam = new javax.swing.JTextField();
        dniFam = new javax.swing.JTextField();
        domFam = new javax.swing.JTextField();
        registrar = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        apeFam = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        dni.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dni.setText("N° Documento:");

        dom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dom.setText("Domicilio:");

        nomFam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomFamActionPerformed(evt);
            }
        });
        nomFam.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nomFamKeyTyped(evt);
            }
        });

        dniFam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dniFamActionPerformed(evt);
            }
        });
        dniFam.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniFamKeyTyped(evt);
            }
        });

        registrar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        registrar.setText("Registrar");
        registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarActionPerformed(evt);
            }
        });

        cancelar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel1.setText("Apellido:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(registrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 172, Short.MAX_VALUE)
                        .addComponent(cancelar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nom)
                            .addComponent(dni)
                            .addComponent(dom)
                            .addComponent(jLabel1))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(apeFam, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(dniFam)
                            .addComponent(domFam)
                            .addComponent(nomFam, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nom)
                    .addComponent(nomFam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(apeFam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dniFam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dni))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dom)
                    .addComponent(domFam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registrar)
                    .addComponent(cancelar))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nomFamKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomFamKeyTyped

    }//GEN-LAST:event_nomFamKeyTyped

    private void dniFamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dniFamActionPerformed

    }//GEN-LAST:event_dniFamActionPerformed

    private void dniFamKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniFamKeyTyped
        if(this.dniFam.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniFamKeyTyped

    private void registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarActionPerformed

        try{
            String aux1 = this.nomFam.getText().trim();
            String aux2 = this.apeFam.getText().trim();
            String aux3 = this.domFam.getText().trim();
            if(aux1.equals("") || aux2.equals("")|| aux3.equals("")){
                throw new CampoVacio();
            }
            else{
                Familiar fa =new Familiar(this.nomFam.getText(),this.apeFam.getText(),this.dniFam.getText(),this.domFam.getText());
                this.familia.add(fa);
                afiliado.setFamiliar(familia);
                JOptionPane.showMessageDialog(rootPane, "Familiar Registrado");
            }
        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        }catch(AfiliadoExistente e){
            JOptionPane.showMessageDialog(rootPane,"Familiar ya Registrado","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campo Vacio","ATENCION",0);
        }
        this.nomFam.setText(null);
        this.apeFam.setText(null);
        this.dniFam.setText(null);
        this.domFam.setText(null);

    }//GEN-LAST:event_registrarActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    private void nomFamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomFamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomFamActionPerformed
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apeFam;
    private javax.swing.JButton cancelar;
    private javax.swing.JLabel dni;
    private javax.swing.JTextField dniFam;
    private javax.swing.JLabel dom;
    private javax.swing.JTextField domFam;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nomFam;
    private javax.swing.JButton registrar;
    // End of variables declaration//GEN-END:variables
}
