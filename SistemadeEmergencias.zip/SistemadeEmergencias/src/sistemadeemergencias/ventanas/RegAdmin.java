package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.CampoVacio;


public class RegAdmin extends javax.swing.JFrame {
    private Administracion admin;
    //private ValidarCampo va = new ValidarCampo();
   
    public RegAdmin(Administracion admin) {
        this.admin=admin;
        initComponents();
        /*va.soloLetra(nombreAdmi);
        va.soloNumero(dniAdmini);
        va.soloNumero(edadAdmi);*/
        
        
    }

            

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        nom = new javax.swing.JLabel();
        dni = new javax.swing.JLabel();
        dom = new javax.swing.JLabel();
        nombreAdmi = new javax.swing.JTextField();
        dniAdmini = new javax.swing.JTextField();
        domAdmin = new javax.swing.JTextField();
        registrarAdmi = new javax.swing.JButton();
        cancelarAdmi = new javax.swing.JButton();
        ape = new javax.swing.JLabel();
        apeAdmin = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        dni.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dni.setText("N° Documento:");

        dom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dom.setText("Domicilio:");

        nombreAdmi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombreAdmiKeyTyped(evt);
            }
        });

        dniAdmini.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dniAdminiActionPerformed(evt);
            }
        });
        dniAdmini.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniAdminiKeyTyped(evt);
            }
        });

        registrarAdmi.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        registrarAdmi.setText("Registrar");
        registrarAdmi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarAdmiActionPerformed(evt);
            }
        });

        cancelarAdmi.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        cancelarAdmi.setText("Cancelar");
        cancelarAdmi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarAdmiActionPerformed(evt);
            }
        });

        ape.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        ape.setText("Apellido:");

        apeAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apeAdminActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(nom)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(nombreAdmi, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(registrarAdmi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cancelarAdmi))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(dom)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                        .addComponent(domAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dni)
                            .addComponent(ape))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(dniAdmini, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(apeAdmin))))
                .addGap(50, 50, 50))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nom)
                    .addComponent(nombreAdmi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ape)
                    .addComponent(apeAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dniAdmini, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dni))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dom)
                    .addComponent(domAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registrarAdmi)
                    .addComponent(cancelarAdmi))
                .addGap(24, 24, 24))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 47, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void nombreAdmiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreAdmiKeyTyped
                

    }//GEN-LAST:event_nombreAdmiKeyTyped

    private void dniAdminiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dniAdminiActionPerformed

    }//GEN-LAST:event_dniAdminiActionPerformed

    private void dniAdminiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniAdminiKeyTyped
       
        if(this.dniAdmini.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniAdminiKeyTyped

    private void registrarAdmiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarAdmiActionPerformed

        try{
            String aux1=this.nombreAdmi.getText().trim();
            String aux2=this.domAdmin.getText().trim();
            if(aux1.equals("") || aux2.equals("")){
                throw new CampoVacio();
            }
            else{
                Administrativo admi =new Administrativo(this.nombreAdmi.getText(),this.apeAdmin.getText(),this.dniAdmini.getText(),this.domAdmin.getText());
                this.admin.añadir(admi);
                JOptionPane.showMessageDialog(rootPane, "Administrativo Registrado");
            }

        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        }catch(AfiliadoExistente e){
            JOptionPane.showMessageDialog(rootPane,"Afiliado ya Registrado","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campos Vacio","ATENCION",0);
        }
        this.nombreAdmi.setText(null);
        this.apeAdmin.setText(null);
        this.dniAdmini.setText(null);
        this.domAdmin.setText(null);
    }//GEN-LAST:event_registrarAdmiActionPerformed

    private void cancelarAdmiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarAdmiActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_cancelarAdmiActionPerformed

    private void apeAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apeAdminActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apeAdminActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ape;
    private javax.swing.JTextField apeAdmin;
    private javax.swing.JButton cancelarAdmi;
    private javax.swing.JLabel dni;
    private javax.swing.JTextField dniAdmini;
    private javax.swing.JLabel dom;
    private javax.swing.JTextField domAdmin;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nombreAdmi;
    private javax.swing.JButton registrarAdmi;
    // End of variables declaration//GEN-END:variables
}
