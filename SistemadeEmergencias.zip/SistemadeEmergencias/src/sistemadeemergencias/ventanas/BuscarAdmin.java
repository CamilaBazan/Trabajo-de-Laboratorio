package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import javax.swing.JOptionPane;


public class BuscarAdmin extends javax.swing.JFrame {
    private Administrativo persona;
    private Administracion admin;
   
    public BuscarAdmin(Administracion admin) {
        this.admin=admin;
        
        initComponents();
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        dni = new javax.swing.JLabel();
        dniAdmi = new javax.swing.JTextField();
        buscarAdmi = new javax.swing.JButton();
        nom = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nombreAdmi = new javax.swing.JTextField();
        domicilioAdmi = new javax.swing.JTextField();
        limpiarAdmi = new javax.swing.JButton();
        editarAdministrativo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        apeAdmin = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        dni.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dni.setText("Ingrese N° Documento:");

        dniAdmi.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniAdmiKeyTyped(evt);
            }
        });

        buscarAdmi.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        buscarAdmi.setText("Buscar");
        buscarAdmi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarAdmiActionPerformed(evt);
            }
        });

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel4.setText("Domicilio:");

        limpiarAdmi.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        limpiarAdmi.setText("Limpiar Campo");
        limpiarAdmi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarAdmiActionPerformed(evt);
            }
        });

        editarAdministrativo.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        editarAdministrativo.setText("Editar Información");
        editarAdministrativo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarAdministrativoActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel1.setText("Apellido:");

        apeAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apeAdminActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(196, 196, 196)
                        .addComponent(dniAdmi, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(buscarAdmi))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nom)
                                    .addComponent(dni)
                                    .addComponent(jLabel1)))
                            .addComponent(limpiarAdmi)
                            .addComponent(jLabel4))
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(domicilioAdmi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nombreAdmi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(apeAdmin, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(editarAdministrativo, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dni)
                    .addComponent(dniAdmi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarAdmi))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(nom)
                    .addComponent(nombreAdmi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(apeAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(44, 44, 44)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(domicilioAdmi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(limpiarAdmi)
                    .addComponent(editarAdministrativo))
                .addGap(34, 34, 34))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 17, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dniAdmiKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniAdmiKeyTyped
        if(this.dniAdmi.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniAdmiKeyTyped

    private void buscarAdmiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarAdmiActionPerformed

        try{
            persona = (Administrativo)this.admin.buscar(this.dniAdmi.getText());
            this.nombreAdmi.setText(persona.getNombre());
            this.apeAdmin.setText(persona.getApellido());
            this.domicilioAdmi.setText(persona.getDomicilio());
            
        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);

        }catch(java.lang.NullPointerException e){
            JOptionPane.showMessageDialog(rootPane,"Administrativo no Registrado","ATENCION",0);
        }catch(java.lang.ClassCastException e){
            JOptionPane.showMessageDialog(rootPane,"Administrativo no existente no existente","ATENCION",0);
        }
    }//GEN-LAST:event_buscarAdmiActionPerformed

    private void limpiarAdmiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarAdmiActionPerformed
        this.dniAdmi.setText(null);
        this.nombreAdmi.setText(null);
        this.apeAdmin.setText(null);
        this.domicilioAdmi.setText(null);
        
    }//GEN-LAST:event_limpiarAdmiActionPerformed

    private void editarAdministrativoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarAdministrativoActionPerformed
        try{
            EditarAdmin edi = new EditarAdmin(admin,persona);
            edi.setTitle("EDITAR ADMINISTRATIVO");
            edi.setLocationRelativeTo(null);
            edi.setVisible(true);
           this.setVisible(false);
        }catch(java.lang.NullPointerException e){
            JOptionPane.showMessageDialog(rootPane,"Buscar Administrativo","ATENCION",0);
        }
    }//GEN-LAST:event_editarAdministrativoActionPerformed

    private void apeAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apeAdminActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apeAdminActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apeAdmin;
    private javax.swing.JButton buscarAdmi;
    private javax.swing.JLabel dni;
    private javax.swing.JTextField dniAdmi;
    private javax.swing.JTextField domicilioAdmi;
    private javax.swing.JButton editarAdministrativo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton limpiarAdmi;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nombreAdmi;
    // End of variables declaration//GEN-END:variables
}
