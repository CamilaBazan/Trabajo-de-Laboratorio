package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.CampoVacio;


public class RegDoctor extends javax.swing.JFrame {
    private  Administracion admin;
    //private ValidarCampo campo = new ValidarCampo();
    
    public RegDoctor(Administracion admin) {
        this.admin=admin;
        initComponents();
        /*campo.soloLetra(nombreD);
        campo.soloNumero(dniD);
        campo.soloNumero(edadD);
        campo.soloLetra(especialidadD);*/
        
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        nom = new javax.swing.JLabel();
        dni = new javax.swing.JLabel();
        dom = new javax.swing.JLabel();
        esp = new javax.swing.JLabel();
        nombreD = new javax.swing.JTextField();
        dniD = new javax.swing.JTextField();
        domicilioD = new javax.swing.JTextField();
        especialidadD = new javax.swing.JTextField();
        registrar = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        ape = new javax.swing.JLabel();
        apeDoc = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        dni.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dni.setText("N° Documento:");

        dom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dom.setText("Domicilio:");

        esp.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        esp.setText("Especialidad:");

        nombreD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nombreDKeyTyped(evt);
            }
        });

        dniD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dniDActionPerformed(evt);
            }
        });
        dniD.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniDKeyTyped(evt);
            }
        });

        registrar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        registrar.setText("Registrar");
        registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarActionPerformed(evt);
            }
        });

        cancelar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });

        ape.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        ape.setText("Apellido:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addComponent(registrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 151, Short.MAX_VALUE)
                        .addComponent(cancelar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(esp)
                            .addComponent(dom)
                            .addComponent(dni)
                            .addComponent(nom)
                            .addComponent(ape))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nombreD)
                            .addComponent(dniD)
                            .addComponent(domicilioD)
                            .addComponent(especialidadD, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(apeDoc))))
                .addGap(78, 78, 78))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(apeDoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(19, 19, 19)
                        .addComponent(dniD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nombreD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nom))
                        .addGap(18, 18, 18)
                        .addComponent(ape)
                        .addGap(23, 23, 23)
                        .addComponent(dni)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dom, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(domicilioD, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(esp)
                    .addComponent(especialidadD, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registrar)
                    .addComponent(cancelar))
                .addGap(35, 35, 35))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void registrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarActionPerformed
        
        
        try{
            String aux1=this.nombreD.getText().trim();
            String aux2=this.apeDoc.getText().trim();
            String aux3=this.domicilioD.getText().trim();
            String aux4 = this.especialidadD.getText().trim();
            if(aux1.equals("") || aux2.equals("") || aux3.equals("")|| aux4.equals("")){
                
                throw new CampoVacio();
            }
            else{
                
                Doctor doc =new Doctor(this.especialidadD.getText(),this.nombreD.getText(),this.apeDoc.getText(),this.dniD.getText(),this.domicilioD.getText());
                this.admin.añadir(doc);
                JOptionPane.showMessageDialog(rootPane, "Doctor Registrado");
            }
        }catch(java.lang.NumberFormatException e){
                JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        }catch(AfiliadoExistente e){
            JOptionPane.showMessageDialog(rootPane,"Afiliado ya Registrado","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campo Vacio","ATENCION",0);
        }
        this.nombreD.setText(null);
        this.apeDoc.setText(null);
        this.dniD.setText(null);
        this.domicilioD.setText(null);
         this.especialidadD.setText(null);
       
    }//GEN-LAST:event_registrarActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    private void nombreDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nombreDKeyTyped
        
    }//GEN-LAST:event_nombreDKeyTyped

    private void dniDKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniDKeyTyped
        if(this.dniD.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniDKeyTyped

    private void dniDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dniDActionPerformed
        
    }//GEN-LAST:event_dniDActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ape;
    private javax.swing.JTextField apeDoc;
    private javax.swing.JButton cancelar;
    private javax.swing.JLabel dni;
    private javax.swing.JTextField dniD;
    private javax.swing.JLabel dom;
    private javax.swing.JTextField domicilioD;
    private javax.swing.JLabel esp;
    private javax.swing.JTextField especialidadD;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nombreD;
    private javax.swing.JButton registrar;
    // End of variables declaration//GEN-END:variables
}
