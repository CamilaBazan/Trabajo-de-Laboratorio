package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.CampoVacio;


public class RegEnfermero extends javax.swing.JFrame {
    private final Administracion admin;
    //private ValidarCampo campo = new ValidarCampo();
    public RegEnfermero(Administracion admin) {
        this.admin=admin;
        initComponents();
        /*campo.soloLetra(nomEnf);
        campo.soloNumero(dniEnf);
        campo.soloNumero(edadE);*/
        
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        nom = new javax.swing.JLabel();
        p = new javax.swing.JLabel();
        dom = new javax.swing.JLabel();
        nomEnf = new javax.swing.JTextField();
        dniEnf = new javax.swing.JTextField();
        domEnf = new javax.swing.JTextField();
        registrarE = new javax.swing.JButton();
        cancelarE = new javax.swing.JButton();
        ape = new javax.swing.JLabel();
        apeEnf = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        p.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        p.setText("N° Documento:");

        dom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dom.setText("Domicilio:");

        nomEnf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nomEnfKeyTyped(evt);
            }
        });

        dniEnf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dniEnfActionPerformed(evt);
            }
        });
        dniEnf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniEnfKeyTyped(evt);
            }
        });

        registrarE.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        registrarE.setText("Registrar");
        registrarE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarEActionPerformed(evt);
            }
        });

        cancelarE.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        cancelarE.setText("Cancelar");
        cancelarE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarEActionPerformed(evt);
            }
        });

        ape.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        ape.setText("Apellido:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dom)
                            .addComponent(p)
                            .addComponent(nom)
                            .addComponent(ape))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nomEnf, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(dniEnf)
                            .addComponent(domEnf)
                            .addComponent(apeEnf)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(registrarE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 177, Short.MAX_VALUE)
                        .addComponent(cancelarE)))
                .addGap(78, 78, 78))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nom)
                    .addComponent(nomEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ape)
                    .addComponent(apeEnf, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dniEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(p))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dom)
                    .addComponent(domEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registrarE)
                    .addComponent(cancelarE))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nomEnfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomEnfKeyTyped

    }//GEN-LAST:event_nomEnfKeyTyped

    private void dniEnfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dniEnfActionPerformed

    }//GEN-LAST:event_dniEnfActionPerformed

    private void dniEnfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniEnfKeyTyped
        if(this.dniEnf.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniEnfKeyTyped

    private void registrarEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarEActionPerformed

        try{
            String aux1 = this.nomEnf.getText().trim();
            String aux2 = this.domEnf.getText().trim();
            if(aux1.equals("")||aux2.equals("")){
                throw new CampoVacio();
            }
            else{
                Enfermero enfer =new Enfermero(this.nomEnf.getText(),this.apeEnf.getText(),this.dniEnf.getText(),this.domEnf.getText());
                this.admin.añadir(enfer);
                JOptionPane.showMessageDialog(rootPane, "Enfermero Registrado");
            }
        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        }catch(AfiliadoExistente e){
            JOptionPane.showMessageDialog(rootPane,"Afiliado ya Registrado","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campos Vacios","ATENCION",0);
        }
        this.nomEnf.setText(null);
        this.apeEnf.setText(null);
        this.dniEnf.setText(null);
        this.domEnf.setText(null);
        

    }//GEN-LAST:event_registrarEActionPerformed

    private void cancelarEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarEActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_cancelarEActionPerformed
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ape;
    private javax.swing.JTextField apeEnf;
    private javax.swing.JButton cancelarE;
    private javax.swing.JTextField dniEnf;
    private javax.swing.JLabel dom;
    private javax.swing.JTextField domEnf;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nomEnf;
    private javax.swing.JLabel p;
    private javax.swing.JButton registrarE;
    // End of variables declaration//GEN-END:variables
}
