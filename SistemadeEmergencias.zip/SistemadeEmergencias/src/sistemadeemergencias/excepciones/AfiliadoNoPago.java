package sistemadeemergencias.excepciones;

public class AfiliadoNoPago extends RuntimeException{
    public AfiliadoNoPago(String mensaje) {
        super("El afiliado no pago a tiempo no se puede enviar la solicitud medica");
    }
}
