package sistemadeemergencias;

public class Doctor extends Empleado{
    
    private String especialidad;
    private Boolean disponible;

    public Doctor(String nombre, String apellido, String domicilio, String dni,String especialidad) {
        super(nombre, apellido, domicilio, dni);
        
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setDni(dni);
        this.especialidad=especialidad;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    
    public Boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }
}
