package sistemadeemergencias;

public class Chofer extends Empleado{
    
    private Boolean disponible;
    
    public Chofer(String nombre, String apellido, String domicilio, String dni) {
        super(nombre, apellido, domicilio, dni);
        
        this.setDni(dni);
        this.setApellido(apellido);
        this.setDomicilio(domicilio);
        this.setNombre(nombre);

    }
    
    public Boolean getDisponible() {
        return disponible;
    }

    public void setDisponible(Boolean disponible) {
        this.disponible = disponible;
    }
}
