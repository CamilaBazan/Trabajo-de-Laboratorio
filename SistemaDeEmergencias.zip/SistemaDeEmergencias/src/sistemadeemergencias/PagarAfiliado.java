package sistemadeemergencias;

import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.CampoVacio;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PagarAfiliado {
    
    private final int IMPORTE_POR_MES=300;
    private ArrayList pagos = new ArrayList();
    private Afiliado afiliado;
    
    
    public PagarAfiliado(Afiliado afiliado){
        this.afiliado=afiliado;
    }
    public class Cuota{
        private int mes;
        private int año;
        public Cuota(int mes,int año){
            this.año=año;
            this.mes=mes;
        }
    }
    
    public int cantFamiliares(){
        int i=0;
        for(Object c :afiliado.getListaFam()){
            i++;
        }
        return i;
    }
    
    public void agregarPago(int importe,int mes,int año){
        int cantFam = cantFamiliares();
        
        if(importe==IMPORTE_POR_MES+50*cantFam){
            Cuota c = new Cuota(mes,año);
            pagos.add(c);
            JOptionPane.showMessageDialog(null,"Pago Existoso");
        }else{
            if(importe<IMPORTE_POR_MES+50*cantFam){
                JOptionPane.showMessageDialog(null,"Importe Menor al Solicitado","ATENCION",0);
            }else{
                
                    JOptionPane.showMessageDialog(null,"Importe Mayor al Solicitado","ATENCION",0);
                }
        }
    }
    public boolean compararMes(){
        Boolean resultado;
        Calendar  fecha =  Calendar.getInstance();
        Cuota c = getUltimaCuota();
        if(c.año==fecha.get(Calendar.YEAR)){
            if((fecha.get(Calendar.MONTH)-c.mes)<=2){
                resultado=true;
            }else{
                resultado=false;
            }
        }else{
            resultado=false;
        }
        return resultado;
            
    }
    public Cuota getUltimaCuota(){
        int i=1;
        Cuota c;
        c=null;
        for(Object cuota:pagos){
            if((pagos.size()-i)==0){
                c=(Cuota)cuota;
            }
            i++;
        }
        return c;
    }
}
