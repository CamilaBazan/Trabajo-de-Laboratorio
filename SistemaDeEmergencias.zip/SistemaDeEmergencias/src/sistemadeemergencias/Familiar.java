package sistemadeemergencias;

import java.util.ArrayList;

public class Familiar extends Persona{
    
    private ArrayList familia;
    
    public Familiar(String nombre,String apellido,String dni,String domicilio){
        super();
        this.setNombre(nombre);
        this.setApellido(apellido);
        this.setDni(dni);
        this.setDomicilio(domicilio);
        familia = new ArrayList();
    }

    @Override
    public String toString() {
        return "Nombre: "+this.getNombre()+"    Apellido: "+this.getApellido()+"     Dni: "+this.getDni()+"    Domicilio: "+this.getDomicilio();
    }
}
