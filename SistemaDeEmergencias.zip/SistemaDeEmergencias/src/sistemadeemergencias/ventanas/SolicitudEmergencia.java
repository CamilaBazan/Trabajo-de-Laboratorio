package sistemadeemergencias.ventanas;

import java.text.SimpleDateFormat;
import java.util.Date;
import sistemadeemergencias.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.AfiliadoInexistente;
import sistemadeemergencias.excepciones.CampoVacio;


public class SolicitudEmergencia extends javax.swing.JFrame {
    private SolicitudMedica solicitud;
    private Administracion admin;
    private Afiliado persona;
    private Doctor doctor;
    private Enfermero enfermero;
    private Chofer chofer;
    private Movil movil;
    
    public SolicitudEmergencia(Administracion admin) {
        this.admin=admin;
        
    initComponents();
    
    fechatxt.setEnabled(false);
    fechatxt.setText(fechaActual());
        
    }

    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        dniS = new javax.swing.JLabel();
        dni = new javax.swing.JTextField();
        SolicitudTitular = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        buscarChof = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        buscarDoc = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        buscarEnf = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        campoDoc = new javax.swing.JTextField();
        campoEnf = new javax.swing.JTextField();
        campoChofer = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        campoMovil = new javax.swing.JTextField();
        buscarMovil = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        fechatxt = new javax.swing.JTextField();

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Ingrese N° Documento:");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        dniS.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dniS.setText("Ingrese N° Documento:");

        SolicitudTitular.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        SolicitudTitular.setText("Solicitar");
        SolicitudTitular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SolicitudTitularActionPerformed(evt);
            }
        });

        cancelar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel2.setText("Doctor:");

        buscarChof.setText("Buscar");
        buscarChof.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarChofActionPerformed(evt);
            }
        });

        jLabel3.setText("Chofer:");

        buscarDoc.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        buscarDoc.setText("Buscar");
        buscarDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarDocActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel4.setText("Enfermero:");

        buscarEnf.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        buscarEnf.setText("Buscar");
        buscarEnf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarEnfActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel5.setText("Equipo Disponible");

        campoDoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoDocActionPerformed(evt);
            }
        });

        campoChofer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoChoferActionPerformed(evt);
            }
        });

        jLabel6.setText("Patente Movil:");

        campoMovil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                campoMovilActionPerformed(evt);
            }
        });

        buscarMovil.setText("Buscar");
        buscarMovil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarMovilActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        jLabel7.setText("Fecha:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel5)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campoDoc, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campoEnf, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(fechatxt, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(buscarEnf, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(buscarDoc))
                                .addGap(26, 26, 26)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addGap(20, 20, 20)
                                        .addComponent(campoMovil))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(campoChofer)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(buscarChof)
                                    .addComponent(buscarMovil)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cancelar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(SolicitudTitular, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(36, 36, 36))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(dniS)
                        .addGap(18, 18, 18)
                        .addComponent(dni, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(358, 385, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dniS)
                    .addComponent(dni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(jLabel5)
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(campoDoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarDoc)
                    .addComponent(jLabel3)
                    .addComponent(buscarChof)
                    .addComponent(campoChofer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(buscarEnf)
                    .addComponent(campoEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(campoMovil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarMovil))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(fechatxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 94, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(cancelar)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(SolicitudTitular)
                        .addGap(20, 20, 20))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static String fechaActual(){
        
    Date fecha = new Date();
    SimpleDateFormat formatoFecha= new SimpleDateFormat("dd/MM/YYYY");
    
    return formatoFecha.format(fecha);
    
    }
    
    private void SolicitudTitularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SolicitudTitularActionPerformed
        try{
            if(this.dni.getText().equals("")==true){
                throw new CampoVacio();
            }else{
                persona = (Afiliado)this.admin.buscar(this.dni.getText());
                Boolean respuesta = persona.getPago().compararMes();
                if(respuesta==false){
                    JOptionPane.showMessageDialog(rootPane,"Solicitud Rechazada","ATENCION",0);
                }
                else{
                    solicitud = new SolicitudMedica(persona,doctor,enfermero,movil);
                    
                  
                    JOptionPane.showMessageDialog(rootPane,"Solicitud Existosa");
                }
            }
        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        }catch(AfiliadoInexistente e){
            JOptionPane.showMessageDialog(rootPane,"Afiliado Inexistente","ATENCION",0);
        }
         catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Ingrese Dni","ATENCION",0);
        }catch (java.lang.NullPointerException ex){
            JOptionPane.showMessageDialog(rootPane,"Personal o Movil no Disponible.","ATENCION",0);
        }    
    }//GEN-LAST:event_SolicitudTitularActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    private void campoDocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoDocActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoDocActionPerformed

    private void campoChoferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoChoferActionPerformed
        
    }//GEN-LAST:event_campoChoferActionPerformed

    private void buscarDocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarDocActionPerformed
       
        doctor =(Doctor) admin.buscarDoc(campoDoc.getText());
        campoDoc.setText((doctor.getNombre())+doctor.getApellido());
       
    }//GEN-LAST:event_buscarDocActionPerformed

    private void buscarEnfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarEnfActionPerformed
       
        enfermero =(Enfermero) admin.buscarEnf(campoEnf.getText());
        campoEnf.setText((enfermero.getNombre())+enfermero.getApellido());
    }//GEN-LAST:event_buscarEnfActionPerformed

    private void campoMovilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoMovilActionPerformed
        // TODO add your handling code here:
        
       
    }//GEN-LAST:event_campoMovilActionPerformed

    private void buscarChofActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarChofActionPerformed
        // TODO add your handling code here:
        chofer =(Chofer) admin.buscarChof(campoChofer.getText());
        campoChofer.setText((chofer.getNombre())+chofer.getApellido());
    }//GEN-LAST:event_buscarChofActionPerformed

    private void buscarMovilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarMovilActionPerformed
        // TODO add your handling code here:
         movil =(Movil) admin.buscarMov(campoMovil.getText());
        campoMovil.setText((movil.getPatente()));
    }//GEN-LAST:event_buscarMovilActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton SolicitudTitular;
    private javax.swing.JButton buscarChof;
    private javax.swing.JButton buscarDoc;
    private javax.swing.JButton buscarEnf;
    private javax.swing.JButton buscarMovil;
    private javax.swing.JTextField campoChofer;
    private javax.swing.JTextField campoDoc;
    private javax.swing.JTextField campoEnf;
    private javax.swing.JTextField campoMovil;
    private javax.swing.JButton cancelar;
    private javax.swing.JTextField dni;
    private javax.swing.JLabel dniS;
    private javax.swing.JTextField fechatxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
