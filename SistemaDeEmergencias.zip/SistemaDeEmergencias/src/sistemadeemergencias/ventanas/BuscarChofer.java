package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.CampoVacio;


public class BuscarChofer extends javax.swing.JFrame {
    private Administracion admin;
    private Chofer persona;
    
    
    public BuscarChofer(Administracion admin) {
        this.admin=admin;
        initComponents();
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        dni = new javax.swing.JLabel();
        dniCh = new javax.swing.JTextField();
        buscarChofer = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nomCh = new javax.swing.JTextField();
        domCh = new javax.swing.JTextField();
        limpiarChofer = new javax.swing.JButton();
        editarChofer = new javax.swing.JButton();
        apeCh = new javax.swing.JTextField();
        ape = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        dni.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dni.setText("Ingrese N° Documento:");

        dniCh.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniChKeyTyped(evt);
            }
        });

        buscarChofer.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        buscarChofer.setText("Buscar");
        buscarChofer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarChoferActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel2.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel4.setText("Domicilio:");

        domCh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                domChActionPerformed(evt);
            }
        });

        limpiarChofer.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        limpiarChofer.setText("Limpiar Campo");
        limpiarChofer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarChoferActionPerformed(evt);
            }
        });

        editarChofer.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        editarChofer.setText("Editar Información");
        editarChofer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarChoferActionPerformed(evt);
            }
        });

        apeCh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apeChActionPerformed(evt);
            }
        });

        ape.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        ape.setText("Apellido:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(limpiarChofer)
                    .addComponent(jLabel2)
                    .addComponent(dni)
                    .addComponent(ape)
                    .addComponent(jLabel4))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(domCh, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                        .addComponent(dniCh, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(nomCh, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(apeCh, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(editarChofer))
                .addGap(28, 28, 28)
                .addComponent(buscarChofer)
                .addContainerGap(94, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dni)
                    .addComponent(dniCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarChofer))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(nomCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ape)
                    .addComponent(apeCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(51, 51, 51)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(domCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(editarChofer)
                    .addComponent(limpiarChofer))
                .addGap(49, 49, 49))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dniChKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniChKeyTyped
        if(this.dniCh.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniChKeyTyped

    private void buscarChoferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarChoferActionPerformed

        try{
            String aux1=this.nomCh.getText().trim();
            String aux2=this.apeCh.getText().trim();
            String aux3=this.domCh.getText().trim();
            String aux4=this.dniCh.getText().trim();
            if(aux1.equals("") || aux2.equals("") || aux3.equals("")|| aux4.equals("")){
                throw new CampoVacio();
            }
            else{
                persona = (Chofer)this.admin.buscar(this.dniCh.getText());
                this.nomCh.setText(persona.getNombre());
                this.domCh.setText(persona.getDomicilio());
                
            }
        }catch(java.lang.NumberFormatException e){  //excepcion para el formato de los campos
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);

        }catch(java.lang.NullPointerException e){  
            JOptionPane.showMessageDialog(rootPane,"Chofer no Registrado","ATENCION",0);
        }catch(java.lang.ClassCastException e){
            JOptionPane.showMessageDialog(rootPane,"Chofer no existente","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Ingrese dni","ATENCION",0);
        }  
    }//GEN-LAST:event_buscarChoferActionPerformed

    private void limpiarChoferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarChoferActionPerformed
        this.dniCh.setText(null);
        this.nomCh.setText(null);
        this.apeCh.setText(null);
        this.domCh.setText(null);
    }//GEN-LAST:event_limpiarChoferActionPerformed

    private void editarChoferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarChoferActionPerformed
        try{
            EditarChofer edi = new EditarChofer(admin,persona);
            edi.setTitle("EDITAR CHOFER");
            edi.setLocationRelativeTo(null);
            edi.setVisible(true);
            this.setVisible(false);
        }catch(java.lang.NullPointerException e){
            JOptionPane.showMessageDialog(rootPane,"Buscar Afiliado","ATENCION",0);
        }
    }//GEN-LAST:event_editarChoferActionPerformed

    private void apeChActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apeChActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apeChActionPerformed

    private void domChActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_domChActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_domChActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ape;
    private javax.swing.JTextField apeCh;
    private javax.swing.JButton buscarChofer;
    private javax.swing.JLabel dni;
    private javax.swing.JTextField dniCh;
    private javax.swing.JTextField domCh;
    private javax.swing.JButton editarChofer;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton limpiarChofer;
    private javax.swing.JTextField nomCh;
    // End of variables declaration//GEN-END:variables
}
