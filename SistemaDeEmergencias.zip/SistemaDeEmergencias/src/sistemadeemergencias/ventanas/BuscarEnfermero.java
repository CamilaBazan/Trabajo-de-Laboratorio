package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.CampoVacio;

public class BuscarEnfermero extends javax.swing.JFrame {
    private Administracion admin;
    private Enfermero persona;
    
    public BuscarEnfermero(Administracion admin) {
        
        this.admin=admin;
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        dniEnfer = new javax.swing.JTextField();
        buscarChofer = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nomEnf = new javax.swing.JTextField();
        domEnf = new javax.swing.JTextField();
        limpiarChofer = new javax.swing.JButton();
        editarenfermero = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        apeEnf = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel1.setText("Ingrese N° Documento:");

        dniEnfer.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniEnferKeyTyped(evt);
            }
        });

        buscarChofer.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        buscarChofer.setText("Buscar");
        buscarChofer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarChoferActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel2.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel4.setText("Domicilio:");

        limpiarChofer.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        limpiarChofer.setText("Limpiar Campo");
        limpiarChofer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limpiarChoferActionPerformed(evt);
            }
        });

        editarenfermero.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        editarenfermero.setText("Editar Información");
        editarenfermero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarenfermeroActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel3.setText("Apellido:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel1)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(limpiarChofer))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(dniEnfer, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                        .addComponent(buscarChofer))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(domEnf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(nomEnf)
                                .addComponent(apeEnf, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                            .addComponent(editarenfermero))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(34, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(dniEnfer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buscarChofer))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(nomEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(apeEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(39, 39, 39)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(domEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(limpiarChofer)
                    .addComponent(editarenfermero))
                .addGap(30, 30, 30))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void dniEnferKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniEnferKeyTyped
        if(dniEnfer.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniEnferKeyTyped

    private void buscarChoferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarChoferActionPerformed

        try{
            if(this.dniEnfer.getText().trim().equals("")){
                throw new CampoVacio();
            }
            else{
                persona = (Enfermero)this.admin.buscar(this.dniEnfer.getText());
                this.nomEnf.setText(persona.getNombre());
                this.apeEnf.setText(persona.getApellido());
                this.domEnf.setText(persona.getDomicilio());

            }
        

        }catch(java.lang.NullPointerException e){
            JOptionPane.showMessageDialog(rootPane,"Enfermero no Registrado","ATENCION",0);
        }catch(java.lang.ClassCastException e){
            JOptionPane.showMessageDialog(rootPane,"Enfermero no existente","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Ingrese dni","ATENCION",0);
        }
    }//GEN-LAST:event_buscarChoferActionPerformed

    private void limpiarChoferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limpiarChoferActionPerformed
        this.dniEnfer.setText(null);
        this.apeEnf.setText(null);
        this.nomEnf.setText(null);
        this.domEnf.setText(null);
    }//GEN-LAST:event_limpiarChoferActionPerformed

    private void editarenfermeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarenfermeroActionPerformed
        try{
            EditarEnfermero edi = new EditarEnfermero(admin,persona);
            edi.setTitle("EDITAR ENFERMERO");
            edi.setLocationRelativeTo(null);
            edi.setVisible(true);
            this.setVisible(false);
        }catch(java.lang.NullPointerException e){
            JOptionPane.showMessageDialog(rootPane,"Buscar ENFERMERO","ATENCION",0);
        }
    }//GEN-LAST:event_editarenfermeroActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apeEnf;
    private javax.swing.JButton buscarChofer;
    private javax.swing.JTextField dniEnfer;
    private javax.swing.JTextField domEnf;
    private javax.swing.JButton editarenfermero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton limpiarChofer;
    private javax.swing.JTextField nomEnf;
    // End of variables declaration//GEN-END:variables
}
