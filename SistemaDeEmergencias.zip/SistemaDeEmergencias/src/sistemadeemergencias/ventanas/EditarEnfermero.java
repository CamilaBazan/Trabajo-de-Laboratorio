package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.CampoVacio;


public class EditarEnfermero extends javax.swing.JFrame {

    private Administracion admin;
    private Enfermero enfermero;
    //private ValidarCampo campo = new ValidarCampo();
    public EditarEnfermero(Administracion admin,Enfermero enfermero) {
        this.admin=admin;
        this.enfermero=enfermero;
        initComponents();
        this.nomEnf.setText(enfermero.getNombre());
        this.apeEnf.setText(enfermero.getApellido());
        this.domEnf.setText(enfermero.getDomicilio());
        //campo.soloLetra(nomEnf);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jlimpiarD = new javax.swing.JButton();
        nom = new javax.swing.JLabel();
        dom = new javax.swing.JLabel();
        nomEnf = new javax.swing.JTextField();
        apeEnf = new javax.swing.JTextField();
        domEnf = new javax.swing.JTextField();
        modificarD = new javax.swing.JButton();
        eliminarD = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jlimpiarD.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jlimpiarD.setText("Limpiar Campo");
        jlimpiarD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jlimpiarDActionPerformed(evt);
            }
        });

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        dom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dom.setText("Domicilio:");

        apeEnf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                apeEnfKeyTyped(evt);
            }
        });

        modificarD.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        modificarD.setText("Modificar");
        modificarD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarDActionPerformed(evt);
            }
        });

        eliminarD.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        eliminarD.setText("Eliminar");
        eliminarD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarDActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel1.setText("Apellido:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(59, Short.MAX_VALUE)
                .addComponent(modificarD)
                .addGap(372, 372, 372))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nom)
                            .addComponent(jLabel1))
                        .addGap(74, 74, 74)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nomEnf, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(apeEnf)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(dom)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                                .addComponent(eliminarD)
                                .addGap(52, 52, 52)
                                .addComponent(jlimpiarD))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(67, 67, 67)
                                .addComponent(domEnf, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nom)
                    .addComponent(nomEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(apeEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(domEnf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dom))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modificarD)
                    .addComponent(eliminarD)
                    .addComponent(jlimpiarD))
                .addGap(64, 64, 64))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 8, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void apeEnfKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_apeEnfKeyTyped
        if(this.apeEnf.getText().length()>=2){
            evt.consume();
        }
    }//GEN-LAST:event_apeEnfKeyTyped

    private void modificarDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarDActionPerformed
        try{
            String aux1 = this.nomEnf.getText().trim();
            String aux2 = this.apeEnf.getText().trim();
            String aux3 = this.domEnf.getText().trim();
            if(aux1.equals("") || aux2.equals("")|| aux3.equals("")){
                throw new CampoVacio();
            }
            else{
                enfermero.setNombre(this.nomEnf.getText());
                enfermero.setDomicilio(this.domEnf.getText());
                enfermero.setApellido(this.apeEnf.getText());
            }
            JOptionPane.showMessageDialog(rootPane, "Enfermero Modificado");
        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campo Vacio","ATENCION",0);
        }

    }//GEN-LAST:event_modificarDActionPerformed

    private void eliminarDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarDActionPerformed
        try{
            String aux1=this.nomEnf.getText().trim();
            String aux2=this.domEnf.getText().trim();
            String aux3 =this.apeEnf.getText().trim();
            
            if(aux1.equals("") || aux2.equals("") || aux3.equals("")){
                throw new CampoVacio();

            }
            else{
                this.admin.eliminar(enfermero.getDni());
                JOptionPane.showMessageDialog(rootPane, "Enfermero Eliminado");
                this.domEnf.setText(null);
                this.apeEnf.setText(null);
                this.nomEnf.setText(null);
                
            }
        
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campo Vacio","ATENCION",0);
        }

    }//GEN-LAST:event_eliminarDActionPerformed

    private void jlimpiarDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jlimpiarDActionPerformed

        this.domEnf.setText(null);
        this.apeEnf.setText(null);
        this.nomEnf.setText(null);

    }//GEN-LAST:event_jlimpiarDActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField apeEnf;
    private javax.swing.JLabel dom;
    private javax.swing.JTextField domEnf;
    private javax.swing.JButton eliminarD;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jlimpiarD;
    private javax.swing.JButton modificarD;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nomEnf;
    // End of variables declaration//GEN-END:variables
}
