package sistemadeemergencias.ventanas;

import sistemadeemergencias.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.CampoVacio;


public class RegChofer extends javax.swing.JFrame {
    private Administracion admin;
    //private ValidarCampo campo = new ValidarCampo();
   
    public RegChofer(Administracion admin) {
        this.admin=admin;
        initComponents();
        /*campo.soloLetra(nomCh);
        campo.soloNumero(dniCh);*/
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        nom = new javax.swing.JLabel();
        dni = new javax.swing.JLabel();
        dom = new javax.swing.JLabel();
        nomCh = new javax.swing.JTextField();
        dniCh = new javax.swing.JTextField();
        domCh = new javax.swing.JTextField();
        registrarChofer = new javax.swing.JButton();
        cancelar = new javax.swing.JButton();
        ape = new javax.swing.JLabel();
        apeCh = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        nom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        nom.setText("Nombre:");

        dni.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dni.setText("N° Documento:");

        dom.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        dom.setText("Domicilio:");

        nomCh.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                nomChKeyTyped(evt);
            }
        });

        dniCh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dniChActionPerformed(evt);
            }
        });
        dniCh.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dniChKeyTyped(evt);
            }
        });

        registrarChofer.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        registrarChofer.setText("Registrar");
        registrarChofer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarChoferActionPerformed(evt);
            }
        });

        cancelar.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        cancelar.setText("Cancelar");
        cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelarActionPerformed(evt);
            }
        });

        ape.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        ape.setText("Apellido:");

        apeCh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apeChActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dom)
                            .addComponent(dni)
                            .addComponent(nom)
                            .addComponent(ape))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(nomCh, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(dniCh)
                            .addComponent(domCh)
                            .addComponent(apeCh)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(registrarChofer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 160, Short.MAX_VALUE)
                        .addComponent(cancelar)))
                .addGap(78, 78, 78))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nom)
                    .addComponent(nomCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ape)
                    .addComponent(apeCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dni)
                    .addComponent(dniCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dom)
                    .addComponent(domCh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(registrarChofer)
                    .addComponent(cancelar))
                .addGap(27, 27, 27))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nomChKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nomChKeyTyped

    }//GEN-LAST:event_nomChKeyTyped

    private void dniChActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dniChActionPerformed

    }//GEN-LAST:event_dniChActionPerformed

    private void dniChKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dniChKeyTyped
        if(this.dniCh.getText().length()>=8){
            evt.consume();
        }
    }//GEN-LAST:event_dniChKeyTyped

    private void registrarChoferActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarChoferActionPerformed

        try{
            String aux1=this.nomCh.getText().trim();
            String aux2=this.apeCh.getText().trim();
            String aux3=this.domCh.getText().trim();
            String aux4=this.dniCh.getText().trim();
            if(aux1.equals("") || aux2.equals("") || aux3.equals("")|| aux4.equals("")){
                throw new CampoVacio();
                
            }
            else{

            Chofer chofer =new Chofer(this.nomCh.getText(),this.apeCh.getText(),this.dniCh.getText(),this.domCh.getText());
            this.admin.añadir(chofer);
            JOptionPane.showMessageDialog(rootPane, "Chofer Registrado");
            }

        }catch(java.lang.NumberFormatException e){
            JOptionPane.showMessageDialog(rootPane,"Error en el formato de dato","ATENCION",0);
        }catch(AfiliadoExistente e){
            JOptionPane.showMessageDialog(rootPane,"Afiliado ya Registrado","ATENCION",0);
        
        } catch (CampoVacio ex) {
            JOptionPane.showMessageDialog(rootPane,"Campos Vacio","ATENCION",0);
        }
        this.nomCh.setText(null);
        this.apeCh.setText(null);
        this.dniCh.setText(null);
        this.domCh.setText(null);

    }//GEN-LAST:event_registrarChoferActionPerformed

    private void cancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelarActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_cancelarActionPerformed

    private void apeChActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apeChActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_apeChActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ape;
    private javax.swing.JTextField apeCh;
    private javax.swing.JButton cancelar;
    private javax.swing.JLabel dni;
    private javax.swing.JTextField dniCh;
    private javax.swing.JLabel dom;
    private javax.swing.JTextField domCh;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel nom;
    private javax.swing.JTextField nomCh;
    private javax.swing.JButton registrarChofer;
    // End of variables declaration//GEN-END:variables
}
