package sistemadeemergencias;

import java.time.LocalDate;

public class SolicitudMedica {
    
    private Persona paciente;
    private Doctor doctor;
    private Enfermero enfermero;
    private Movil movil;
    private String diagnostico;
    private Afiliado afiliado;
    private Chofer chofer;
    private LocalDate fecha;

    public SolicitudMedica(Persona paciente,Doctor doctor,Enfermero enfermero,Movil movil) {
        this.paciente=paciente;
        this.doctor=doctor;
        this.enfermero=enfermero;
        this.movil=movil;
   
    }
    
    public SolicitudMedica(Afiliado afiliado, Movil movil, LocalDate fecha, Enfermero enfermero, Doctor doctor, Chofer chofer) {
        this.afiliado = afiliado;
        this.movil = movil;
        this.fecha = fecha;
        this.enfermero = enfermero;
        this.doctor = doctor;
        this.chofer = chofer;
    }    

    public Persona getPaciente() {
        return paciente;
    }

    public void setPaciente(Persona paciente) {
        this.paciente = paciente;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }
 
    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Enfermero getEnfermero() {
        return enfermero;
    }

    public void setEnfermero(Enfermero enfermero) {
        this.enfermero = enfermero;
    }

    public Movil getMovil() {
        return movil;
    }

    public void setMovil(Movil movil) {
        this.movil = movil;
    }
    
}
