package sistemadeemergencias;

import java.awt.Component;
import java.util.ArrayList;
import java.util.Iterator;
import javax.swing.JOptionPane;
import sistemadeemergencias.excepciones.AfiliadoExistente;
import sistemadeemergencias.excepciones.AfiliadoInexistente;

public class GestionEmergencia implements Administracion{
    
    private ArrayList<Empleado> empleados = new ArrayList<>();
    private final ArrayList registro = new ArrayList();
    private final ArrayList moviles = new ArrayList();
    private Component rootPane;
    private Object d;
    private Object mov;
    
 
    @Override
    public void añadir(Object per) {
        
      Persona pe = (Persona)per;
      Persona existe = (Persona)buscar(pe.getDni());
        if (existe != null) {
            JOptionPane.showMessageDialog(rootPane,"Afiliado ya Registrado","ATENCION",0);
        }
        registro.add(pe);
    }

    @Override
    public void eliminar(String dni) {
        Object existe = buscar(dni);
        if (existe != null) {
            registro.remove(existe);            
            return;
        }        
         JOptionPane.showMessageDialog(rootPane,"Afiliado Inexistente","ATENCION",0);
    }

   

    @Override
    public Object buscar(String dni) {
        Persona resultado = null;
         for (Object cuenta : registro) {
            Persona c = (Persona)cuenta;
            if (c.getDni().equals(dni)==true){
                resultado=c;
            }
        }
        return resultado;

    }

    @Override
    public void añadirMovil(Object mov) {
        Movil movil = (Movil)mov;
        Movil existe = (Movil)buscarMovil(movil.getPatente());
        if (existe != null) {
             JOptionPane.showMessageDialog(rootPane,"Movil Existente","ATENCION",0);
        }
        moviles.add(movil);
    }

    @Override
    public void eliminarMovil(String mov) {
        Object existe = buscarMovil(mov);
        if (existe != null) {
            moviles.remove(existe);            
            return;
        }        
         JOptionPane.showMessageDialog(rootPane,"Movil Inexistente","ATENCION",0);
    }

    @Override
    public Object buscarMovil(String patente) {
        Movil resultado = null;
        
            for (Object cuenta : moviles) {
                Movil c = (Movil)cuenta;
                if(c.getPatente().equals(null)){
                    
                }else{
                    if (c.getPatente().equals(patente)==true){
                        resultado=c;
                    }
                }
            }
            return resultado;
        
    }
    public Doctor buscarDoc(String nombre){
        Doctor resultado = null;
        for(Object c : registro){
            if(c.getClass().equals(d.getClass())){
                resultado = (Doctor) c;
                break;
            }
        }
        return resultado;
    }
    public Enfermero buscarEnf(String nombre){
        Enfermero resultado = null;
        for(Object c : registro){
            if(c.getClass().equals(d.getClass())){
                resultado = (Enfermero) c;
                break;
            }
        }
        return resultado;
    }
    @Override
    public Movil buscarMov(String patente){
        Movil resultado = null;
        for(Object c : moviles){
            if(c.getClass().equals(mov.getClass())){
                resultado = (Movil) c;
                break;
            }
        }
        return resultado;
    }
    
    
    public Chofer buscarChof(String nombre){
        Chofer resultado = null;
        for(Object c : registro){
            if(c.getClass().equals(d.getClass())){
                resultado = (Chofer) c;
                break;
            }
        }
        return resultado;
    }

    public Doctor doctorDisponible() {
        Doctor b = null;
        for (Empleado i : empleados) {
            if (i instanceof Doctor) {
                Doctor a = (Doctor) i;
                if (a.getDisponible()) {
                    b = a;
                    b.setDisponible(false);
                    break;
                }
            }

        }
        return b;
    }

    public Enfermero enfermeroDisponible() {
        Enfermero b = null;
        for (Empleado i : empleados) {
            if (i instanceof Enfermero) {
                Enfermero a = (Enfermero) i;
                if (a.getDisponible()) {
                    b = a;
                    b.setDisponible(false);
                    break;
                }
            }

        }
        return b;
    }

    public Chofer choferDisponible() {
        Chofer b = null;
        for (Empleado i : empleados) {
            if (i instanceof Chofer) {
                Chofer a = (Chofer) i;
                if (a.getDisponible()) {
                    b = a;
                    b.setDisponible(false);
                    break;
                }

            }
        }
        return b;
    }

    public Movil movilDisponible() {
        Movil b = null;
        for (Iterator it = moviles.iterator(); it.hasNext();) {
            Movil i = (Movil) it.next();
            if (i.getDisponible()) {
                b = (Movil) i;
                b.setDisponible(false);
                break;
            }
        }

        return b;
    }
}
