package sistemadeemergencias;

public abstract class Persona {
    
    private String nombre;
    private String apellido;
    private String dni;
    private String domicilio;

    public Persona() {
        this.nombre = null;
        this.apellido=null;
        this.dni = null;
        this.domicilio = null;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }
    
    public String getApellido() {
        return apellido;
    }
    
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellido=" + apellido +", dni=" + dni +  '}';
    }

}
