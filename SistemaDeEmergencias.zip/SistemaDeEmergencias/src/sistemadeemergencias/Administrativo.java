package sistemadeemergencias;

public class Administrativo extends Empleado{
    
    public Administrativo(String nombre,String apellido, String dni, String domicilio) {
        super(nombre,apellido,dni,domicilio);
        this.setDni(dni);
        this.setDomicilio(domicilio);
        this.setNombre(nombre);
    }
}

