package sistemadeemergencias;

public interface Administracion {
    
    public abstract void añadir(Object per);
    public abstract void eliminar(String per);
    public abstract Object buscar(String dni);
    public abstract void añadirMovil(Object mov);
    public abstract void eliminarMovil(String mov);
    public abstract Object buscarMovil(String patente);
    public abstract Doctor buscarDoc(String nombre);
    public abstract Enfermero buscarEnf(String nombre);
    public abstract Movil buscarMov(String patente);
    public abstract Chofer buscarChof(String nombre);
}
