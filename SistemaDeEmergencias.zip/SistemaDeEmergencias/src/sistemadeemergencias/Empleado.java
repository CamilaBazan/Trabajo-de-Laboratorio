package sistemadeemergencias;

public class Empleado extends Persona{
    
    public Empleado (String nombre, String apellido, String domicilio , String dni){
       
    }
}
