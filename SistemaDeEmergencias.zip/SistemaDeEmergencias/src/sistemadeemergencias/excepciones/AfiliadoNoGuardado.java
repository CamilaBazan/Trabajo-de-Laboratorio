package sistemadeemergencias.excepciones;

public class AfiliadoNoGuardado extends RuntimeException {
    
    public AfiliadoNoGuardado(String mensaje){
        super("Error");
    }
}
