package sistemadeemergencias.excepciones;

public class CampoVacio extends Exception{
    
}
