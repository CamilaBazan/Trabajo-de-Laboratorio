package sistemadeemergencias.excepciones;

public class AfiliadoExistente extends RuntimeException{
    
    public AfiliadoExistente(String mensaje) {
        super(mensaje);
    }
}
