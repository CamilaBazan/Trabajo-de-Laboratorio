package sistemadeemergencias.excepciones;


public class AfiliadoInexistente extends NullPointerException{
    
    public AfiliadoInexistente(String mensaje){
        super(mensaje);
    }
    
}
