package sistemadeemergencias;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class GestionEmergenciaTest {
    
    public GestionEmergenciaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of añadir method, of class GestionEmergencia.
     */
    @Test
    public void testAñadir() {
        System.out.println("a\u00f1adir");
        Object per = null;
        GestionEmergencia instance = new GestionEmergencia();
        instance.añadir(per);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminar method, of class GestionEmergencia.
     */
    @Test
    public void testEliminar() {
        System.out.println("eliminar");
        String dni = "";
        GestionEmergencia instance = new GestionEmergencia();
        instance.eliminar(dni);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscar method, of class GestionEmergencia.
     */
    @Test
    public void testBuscar() {
        System.out.println("buscar");
        String dni = "";
        GestionEmergencia instance = new GestionEmergencia();
        Object expResult = null;
        Object result = instance.buscar(dni);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of añadirMovil method, of class GestionEmergencia.
     */
    @Test
    public void testAñadirMovil() {
        System.out.println("a\u00f1adirMovil");
        Object mov = null;
        GestionEmergencia instance = new GestionEmergencia();
        instance.añadirMovil(mov);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of eliminarMovil method, of class GestionEmergencia.
     */
    @Test
    public void testEliminarMovil() {
        System.out.println("eliminarMovil");
        String mov = "";
        GestionEmergencia instance = new GestionEmergencia();
        instance.eliminarMovil(mov);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarMovil method, of class GestionEmergencia.
     */
    @Test
    public void testBuscarMovil() {
        System.out.println("buscarMovil");
        String patente = "";
        GestionEmergencia instance = new GestionEmergencia();
        Object expResult = null;
        Object result = instance.buscarMovil(patente);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarDoc method, of class GestionEmergencia.
     */
    @Test
    public void testBuscarDoc() {
        System.out.println("buscarDoc");
        String nombre = "";
        GestionEmergencia instance = new GestionEmergencia();
        Doctor expResult = null;
        Doctor result = instance.buscarDoc(nombre);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarEnf method, of class GestionEmergencia.
     */
    @Test
    public void testBuscarEnf() {
        System.out.println("buscarEnf");
        String nombre = "";
        GestionEmergencia instance = new GestionEmergencia();
        Enfermero expResult = null;
        Enfermero result = instance.buscarEnf(nombre);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarMov method, of class GestionEmergencia.
     */
    @Test
    public void testBuscarMov() {
        System.out.println("buscarMov");
        String patente = "";
        GestionEmergencia instance = new GestionEmergencia();
        Movil expResult = null;
        Movil result = instance.buscarMov(patente);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of buscarChof method, of class GestionEmergencia.
     */
    @Test
    public void testBuscarChof() {
        System.out.println("buscarChof");
        String nombre = "";
        GestionEmergencia instance = new GestionEmergencia();
        Chofer expResult = null;
        Chofer result = instance.buscarChof(nombre);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of doctorDisponible method, of class GestionEmergencia.
     */
    @Test
    public void testDoctorDisponible() {
        System.out.println("doctorDisponible");
        GestionEmergencia instance = new GestionEmergencia();
        Doctor expResult = null;
        Doctor result = instance.doctorDisponible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enfermeroDisponible method, of class GestionEmergencia.
     */
    @Test
    public void testEnfermeroDisponible() {
        System.out.println("enfermeroDisponible");
        GestionEmergencia instance = new GestionEmergencia();
        Enfermero expResult = null;
        Enfermero result = instance.enfermeroDisponible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of choferDisponible method, of class GestionEmergencia.
     */
    @Test
    public void testChoferDisponible() {
        System.out.println("choferDisponible");
        GestionEmergencia instance = new GestionEmergencia();
        Chofer expResult = null;
        Chofer result = instance.choferDisponible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of movilDisponible method, of class GestionEmergencia.
     */
    @Test
    public void testMovilDisponible() {
        System.out.println("movilDisponible");
        GestionEmergencia instance = new GestionEmergencia();
        Movil expResult = null;
        Movil result = instance.movilDisponible();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
